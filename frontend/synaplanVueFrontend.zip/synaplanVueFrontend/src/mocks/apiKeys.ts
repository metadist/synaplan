export interface APIKey {
  id: string
  name: string
  key: string
  status: 'active' | 'inactive'
  created: Date
  lastUsed: Date | null
  usageCount: number
}

export const mockAPIKeys: APIKey[] = [
  {
    id: '1',
    name: 'Server A',
    key: 'sk_live_51NxT8zK9ZqJ3r2Hn4Jk5L6M7N8O9P0Q1R2S3T4U5V6W7X8Y9Z',
    status: 'active',
    created: new Date('2024-01-15'),
    lastUsed: new Date('2025-03-10'),
    usageCount: 1247
  },
  {
    id: '2',
    name: 'Production Server',
    key: 'sk_live_91XyZ8wV7uT6sR5qP4oN3mL2kJ1iH0gF9eD8cB7aZ6yX5wV4u',
    status: 'active',
    created: new Date('2024-02-20'),
    lastUsed: new Date('2025-03-12'),
    usageCount: 5632
  },
  {
    id: '3',
    name: 'Development Server',
    key: 'sk_test_31AbC2dE3fG4hI5jK6lM7nO8pQ9rS0tU1vW2xY3zA4bC5dE6f',
    status: 'inactive',
    created: new Date('2024-03-05'),
    lastUsed: new Date('2025-02-28'),
    usageCount: 892
  }
]

