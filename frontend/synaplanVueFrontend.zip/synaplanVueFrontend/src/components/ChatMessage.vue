<template>
  <div :class="['flex gap-4 p-4 text-[16px] leading-6', role === 'user' ? 'justify-end' : '', isSuperseded && 'opacity-50']">
    <!-- Avatar with provider logo for assistant -->
    <div
      v-if="role === 'assistant'"
      class="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 surface-card"
    >
      <Icon :icon="getProviderIcon(provider || 'OpenAI')" class="w-6 h-6" />
    </div>

    <!-- Single bubble with content + footer -->
    <div :class="['flex flex-col max-w-3xl', role === 'user' ? 'bubble-user' : 'bubble-ai']">
      <!-- Bubble content -->
      <div class="px-4 py-3 overflow-hidden space-y-3">
        <MessagePart
          v-for="(part, index) in parts"
          :key="index"
          :part="part"
        />
      </div>

      <!-- Footer with separator line and responsive layout -->
      <div
        :class="[
          'px-3 md:px-4 py-2 md:py-0 border-t md:h-[46px] flex flex-col md:flex-row md:items-center justify-between gap-2 md:gap-3',
          role === 'user'
            ? 'border-white/20'
            : 'border-light-border/30 dark:border-dark-border/20'
        ]"
      >
        <!-- Left: Model info + timestamp -->
        <div class="flex items-center gap-2 min-w-0">
          <div :class="['text-xs truncate', role === 'user' ? 'text-white/80' : 'txt-secondary']">
            <template v-if="role === 'assistant' && modelLabel && provider">
              <span class="font-medium hidden md:inline">{{ modelLabel }}</span>
              <span class="mx-1.5 opacity-50 hidden md:inline">·</span>
              <span class="hidden md:inline">{{ provider }}</span>
              <span class="mx-1.5 opacity-50 hidden md:inline">·</span>
            </template>
            <span>{{ formattedTime }}</span>
            <template v-if="role === 'assistant' && modelLabel">
              <span class="mx-1.5 opacity-50 md:hidden">·</span>
              <span class="md:hidden">{{ modelLabel }}</span>
            </template>
          </div>
        </div>

        <!-- Right: Actions (assistant only, hidden during streaming) -->
        <div v-if="role === 'assistant' && !isStreaming" class="flex items-center gap-2 flex-shrink-0">
          <button
            @click="handleAgain"
            type="button"
            :disabled="isSuperseded"
            :class="[
              'pill text-xs whitespace-nowrap',
              isSuperseded ? 'opacity-50 cursor-not-allowed' : ''
            ]"
            :aria-label="$t('chatMessage.again')"
          >
            <ArrowPathIcon class="w-4 h-4" />
            <span class="font-medium hidden sm:inline">{{ $t('chatMessage.againWith') }} {{ selectedModel.label }}</span>
            <span class="font-medium sm:hidden">{{ $t('chatMessage.again') }}</span>
          </button>

          <div class="relative">
            <button
              @click.stop="toggleModelDropdown"
              type="button"
              :disabled="isSuperseded"
              :class="[
                'pill text-xs',
                isSuperseded ? 'opacity-50 cursor-not-allowed' : ''
              ]"
              :aria-label="$t('chatMessage.regenerateWith')"
              @keydown.escape="closeModelDropdown"
            >
              <ChevronDownIcon class="w-4 h-4" />
            </button>

            <Transition
              enter-active-class="transition ease-out duration-100"
              enter-from-class="transform opacity-0 scale-95"
              enter-to-class="transform opacity-100 scale-100"
              leave-active-class="transition ease-in duration-75"
              leave-from-class="transform opacity-100 scale-100"
              leave-to-class="transform opacity-0 scale-95"
            >
              <div
                v-if="modelDropdownOpen && !isSuperseded"
                v-click-outside="closeModelDropdown"
                class="fixed sm:absolute bottom-[60px] sm:bottom-full right-2 sm:right-0 sm:mb-2 min-w-[14rem] max-w-[calc(100vw-1rem)] dropdown-panel z-[100] max-h-80 overflow-y-auto scroll-thin"
                @keydown.escape="closeModelDropdown"
              >
                <button
                  v-for="option in modelOptions"
                  :key="`${option.provider}-${option.model}`"
                  @click="selectModel(option)"
                  type="button"
                  :class="[
                    'dropdown-item',
                    selectedModel.model === option.model && selectedModel.provider === option.provider
                      ? 'dropdown-item--active'
                      : ''
                  ]"
                >
                  <Icon :icon="getProviderIcon(option.provider)" class="w-5 h-5 flex-shrink-0" />
                  <div class="flex-1 min-w-0">
                    <div class="text-sm font-medium">{{ option.label }}</div>
                    <div class="text-xs txt-secondary">{{ option.provider }}</div>
                  </div>
                </button>
              </div>
            </Transition>
          </div>
        </div>
      </div>
    </div>

    <!-- Avatar on right for user -->
    <div
      v-if="role === 'user'"
      class="w-10 h-10 rounded-full surface-chip flex items-center justify-center flex-shrink-0"
    >
      <UserIcon class="w-5 h-5 txt-secondary" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { UserIcon, ArrowPathIcon, ChevronDownIcon } from '@heroicons/vue/24/outline'
import { Icon } from '@iconify/vue'
import { useModelsStore } from '@/stores/models'
import { getProviderIcon } from '@/utils/providerIcons'
import MessagePart from './MessagePart.vue'
import type { Part } from '@/stores/history'

interface Props {
  role: 'user' | 'assistant'
  parts: Part[]
  timestamp: Date
  isSuperseded?: boolean
  isStreaming?: boolean
  provider?: string
  modelLabel?: string
}

interface ModelOption {
  provider: string
  model: string
  label: string
}

const props = defineProps<Props>()

const formattedTime = computed(() => {
  const date = props.timestamp
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  return `${hours}:${minutes}`
})

const emit = defineEmits<{
  regenerate: [model: ModelOption]
}>()

const modelsStore = useModelsStore()
const modelDropdownOpen = ref(false)
const selectedModel = ref<ModelOption>({ provider: 'OpenAI', model: 'gpt-4', label: 'GPT-4' })

const defaultModelOptions: ModelOption[] = [
  { provider: 'OpenAI', model: 'gpt-4', label: 'GPT-4' },
  { provider: 'OpenAI', model: 'gpt-4-turbo', label: 'GPT-4 Turbo' },
  { provider: 'OpenAI', model: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo' },
  { provider: 'Anthropic', model: 'claude-3-opus', label: 'Claude 3 Opus' },
  { provider: 'Anthropic', model: 'claude-3-sonnet', label: 'Claude 3 Sonnet' },
  { provider: 'Google', model: 'gemini-pro', label: 'Gemini Pro' },
]

const modelOptions = computed(() => {
  return modelsStore.chatModels.length > 0 
    ? modelsStore.chatModels 
    : defaultModelOptions
})

onMounted(() => {
  const currentModel = modelOptions.value.find(
    (opt) => opt.model === modelsStore.selectedModel && opt.provider === modelsStore.selectedProvider
  )
  if (currentModel) {
    selectedModel.value = currentModel
  }
})

const handleAgain = () => {
  emit('regenerate', selectedModel.value)
}

const toggleModelDropdown = () => {
  modelDropdownOpen.value = !modelDropdownOpen.value
}

const closeModelDropdown = () => {
  modelDropdownOpen.value = false
}

const selectModel = (model: ModelOption) => {
  selectedModel.value = model
  modelDropdownOpen.value = false
}

const vClickOutside = {
  mounted(el: HTMLElement, binding: any) {
    const handler = (event: MouseEvent) => {
      if (!(el === event.target || el.contains(event.target as Node))) {
        binding.value()
      }
    }
    (el as any).__clickOutsideHandler = handler
    setTimeout(() => {
      document.addEventListener('click', handler)
    }, 0)
  },
  unmounted(el: HTMLElement) {
    const handler = (el as any).__clickOutsideHandler
    if (handler) {
      document.removeEventListener('click', handler)
    }
  },
}
</script>
