<template>
  <div class="space-y-6">
    <div class="surface-card p-6">
      <h2 class="text-2xl font-semibold txt-primary mb-6 flex items-center gap-2">
        <CpuChipIcon class="w-6 h-6 text-[var(--brand)]" />
        Default Model Configuration
      </h2>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div
          v-for="(purpose, key) in purposeLabels"
          :key="key"
          class="space-y-2"
        >
          <label class="flex items-center gap-2 text-sm font-semibold txt-primary">
            <CpuChipIcon class="w-4 h-4 text-[var(--brand)]" />
            {{ purpose }}
            <div v-if="isSystemModel(key)" class="ml-auto flex items-center gap-1 px-2 py-0.5 rounded-full bg-yellow-500/10 border border-yellow-500/30">
              <LockClosedIcon class="w-3 h-3 text-yellow-500" />
              <span class="text-xs font-medium text-yellow-500">System</span>
            </div>
          </label>
          <div class="relative">
            <select
              v-model="defaultConfig[key as keyof DefaultModelConfig]"
              :disabled="isSystemModel(key)"
              :class="[
                'w-full px-4 py-3 pl-10 rounded-lg surface-card border txt-primary text-sm focus:outline-none focus:ring-2 focus:ring-[var(--brand)] transition-all appearance-none',
                isSystemModel(key)
                  ? 'border-yellow-500/30 bg-yellow-500/5 cursor-not-allowed opacity-75'
                  : 'border-light-border/30 dark:border-dark-border/20 hover:border-[var(--brand)]/50'
              ]"
            >
              <option
                v-for="model in getModelsByPurpose(key as ModelPurpose)"
                :key="model.id"
                :value="`${model.name} (${model.service})`"
              >
                {{ model.name }} ({{ model.service }})
              </option>
            </select>
            <div class="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none">
              <Icon 
                :icon="getProviderIcon(getSelectedModelService(key as keyof DefaultModelConfig))" 
                class="w-4 h-4" 
              />
            </div>
            <ChevronDownIcon class="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 txt-secondary pointer-events-none" />
          </div>
        </div>
      </div>

      <div class="flex gap-3 justify-end mt-6">
        <button
          @click="resetForm"
          class="px-6 py-2.5 rounded-lg border-2 border-light-border/30 dark:border-dark-border/20 txt-primary hover:bg-black/5 dark:hover:bg-white/5 transition-all text-sm font-medium"
        >
          Reset Form
        </button>
        <button
          @click="saveConfiguration"
          class="btn-primary px-6 py-2.5 rounded-lg flex items-center gap-2 text-sm font-medium"
        >
          <CheckIcon class="w-5 h-5" />
          Save Configuration
        </button>
      </div>

      <div class="mt-4 flex items-start gap-2 p-3 rounded-lg bg-blue-500/5 border border-blue-500/20">
        <InformationCircleIcon class="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
        <span class="text-sm txt-primary">System models are automatically locked and cannot be changed. These are core models required for specific functionality.</span>
      </div>
    </div>

    <div class="surface-card p-6">
      <h2 class="text-xl font-semibold txt-primary mb-4 flex items-center gap-2">
        <FunnelIcon class="w-5 h-5" />
        Models & Purposes
      </h2>

      <div class="flex flex-wrap gap-2">
        <button
          @click="selectedPurpose = null"
          :class="[
            'px-4 py-2 rounded-lg text-sm font-medium transition-all',
            selectedPurpose === null
              ? 'bg-[var(--brand)] text-white'
              : 'border border-light-border/30 dark:border-dark-border/20 txt-secondary hover:bg-black/5 dark:hover:bg-white/5'
          ]"
        >
          All Models
        </button>
        <button
          v-for="key in Object.keys(purposeLabels)"
          :key="key"
          @click="selectedPurpose = key as ModelPurpose"
          :class="[
            'px-4 py-2 rounded-lg text-sm font-medium transition-all',
            selectedPurpose === key
              ? 'bg-[var(--brand)] text-white'
              : 'border border-light-border/30 dark:border-dark-border/20 txt-secondary hover:bg-black/5 dark:hover:bg-white/5'
          ]"
        >
          {{ key }}
        </button>
      </div>
    </div>

    <div class="surface-card p-6">
      <h2 class="text-xl font-semibold txt-primary mb-4 flex items-center gap-2">
        <ListBulletIcon class="w-5 h-5" />
        Available Models
      </h2>

      <div v-if="filteredModels.length === 0" class="text-center py-12 txt-secondary">
        No models available for this purpose
      </div>

      <div v-else class="overflow-x-auto">
        <table class="w-full">
          <thead>
            <tr class="border-b-2 border-light-border/30 dark:border-dark-border/20">
              <th class="text-left py-3 px-3 txt-secondary text-xs font-semibold uppercase tracking-wide">ID</th>
              <th class="text-left py-3 px-3 txt-secondary text-xs font-semibold uppercase tracking-wide">Purpose</th>
              <th class="text-left py-3 px-3 txt-secondary text-xs font-semibold uppercase tracking-wide">Service</th>
              <th class="text-left py-3 px-3 txt-secondary text-xs font-semibold uppercase tracking-wide">Name</th>
              <th class="text-left py-3 px-3 txt-secondary text-xs font-semibold uppercase tracking-wide">Description</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="model in filteredModels"
              :key="model.id"
              class="border-b border-light-border/10 dark:border-dark-border/10 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
            >
              <td class="py-3 px-3">
                <span class="pill text-xs">{{ model.id }}</span>
              </td>
              <td class="py-3 px-3">
                <span class="pill pill--active text-xs">{{ model.purpose }}</span>
              </td>
              <td class="py-3 px-3">
                <div class="flex items-center gap-2">
                  <Icon :icon="getProviderIcon(model.service)" class="w-4 h-4 flex-shrink-0" />
                  <span
                    :class="[
                      'px-3 py-1 rounded-full text-xs font-medium text-white',
                      serviceColors[model.service] || 'bg-gray-500'
                    ]"
                  >
                    {{ model.service }}
                  </span>
                </div>
              </td>
              <td class="py-3 px-3 txt-primary text-sm font-medium">
                {{ model.name }}
              </td>
              <td class="py-3 px-3 txt-secondary text-sm">
                {{ model.description }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import {
  CpuChipIcon,
  CheckIcon,
  InformationCircleIcon,
  LockClosedIcon,
  FunnelIcon,
  ListBulletIcon,
  ChevronDownIcon
} from '@heroicons/vue/24/outline'
import { Icon } from '@iconify/vue'
import type { ModelPurpose, DefaultModelConfig } from '@/mocks/aiModels'
import {
  mockAvailableModels,
  mockDefaultConfig,
  purposeLabels,
  serviceColors
} from '@/mocks/aiModels'
import { useModelsStore } from '@/stores/models'
import { getProviderIcon } from '@/utils/providerIcons'

const modelsStore = useModelsStore()
const defaultConfig = ref<DefaultModelConfig>({ ...mockDefaultConfig })
const selectedPurpose = ref<ModelPurpose | null>(null)

onMounted(() => {
  modelsStore.setAvailableModels(mockAvailableModels)
})

const getModelsByPurpose = (purpose: ModelPurpose) => {
  return mockAvailableModels.filter(model => model.purpose === purpose)
}

const isSystemModel = (purpose: string) => {
  return purpose === 'vectorize'
}

const getSelectedModelService = (purpose: keyof DefaultModelConfig): string => {
  const selectedValue = defaultConfig.value[purpose]
  const serviceName = selectedValue.match(/\(([^)]+)\)$/)?.[1] || ''
  return serviceName
}

const filteredModels = computed(() => {
  const models = modelsStore.availableModels.length > 0 
    ? modelsStore.availableModels 
    : mockAvailableModels
    
  if (selectedPurpose.value === null) {
    return models
  }
  return models.filter(model => model.purpose === selectedPurpose.value)
})

const saveConfiguration = () => {
  console.log('Save configuration:', defaultConfig.value)
}

const resetForm = () => {
  defaultConfig.value = { ...mockDefaultConfig }
}
</script>

