<template>
  <MainLayout>
    <template #header>
    </template>

    <div class="flex flex-col h-full">
      <div ref="chatContainer" class="flex-1 overflow-y-auto bg-chat" @scroll="handleScroll">
        <div class="max-w-4xl mx-auto py-6">
          <div v-if="historyStore.messages.length === 0" class="flex items-center justify-center h-full px-6">
            <div class="text-center">
              <h2 class="text-2xl font-semibold txt-primary mb-2">
                {{ $t('welcome') }}
              </h2>
              <p class="txt-secondary">
                {{ $t('chatInput.placeholder') }}
              </p>
            </div>
          </div>

          <template v-for="(group, groupIndex) in groupedMessages" :key="groupIndex">
            <div class="flex items-center justify-center my-4">
              <div class="px-4 py-1.5 surface-chip text-xs font-medium txt-secondary">
                {{ group.label }}
              </div>
            </div>
            <ChatMessage
              v-for="message in group.messages"
              :key="message.id"
              :role="message.role"
              :parts="message.parts"
              :timestamp="message.timestamp"
              :is-superseded="message.isSuperseded"
              :is-streaming="message.isStreaming"
              :provider="message.provider"
              :model-label="message.modelLabel"
              @regenerate="handleRegenerate(message, $event)"
            />
          </template>
        </div>
      </div>

      <ChatInput 
        :is-streaming="isStreaming" 
        @send="handleSendMessage"
        @stop="handleStopStreaming"
      />
    </div>
  </MainLayout>
</template>

<script setup lang="ts">
import { ref, computed, nextTick, watch } from 'vue'
import MainLayout from '../components/MainLayout.vue'
import ChatInput from '../components/ChatInput.vue'
import ChatMessage from '../components/ChatMessage.vue'
import { useHistoryStore, type Message } from '../stores/history'
import { executeCommand } from '../commands/execute'
import { useModelsStore } from '../stores/models'
import { mockModelOptions, type ModelOption } from '@/mocks/aiModels'

const chatContainer = ref<HTMLElement | null>(null)
const autoScroll = ref(true)
const historyStore = useHistoryStore()
const modelsStore = useModelsStore()
let streamingAbortController: AbortController | null = null

interface MessageGroup {
  label: string
  messages: Message[]
}

const isStreaming = computed(() => {
  return historyStore.messages.some(m => m.isStreaming === true)
})

// Welcome-Message with streaming
const initWelcomeMessage = async () => {
  const messageId = historyStore.addStreamingMessage('assistant', 'OpenAI', 'GPT-4')
  const welcomeText = 'Hello! How can I help you today? Try typing "/" to see available commands.'
  
  const { streamText } = await import('../commands/execute')
  for await (const chunk of streamText(welcomeText, 2)) {
    historyStore.updateStreamingMessage(messageId, chunk)
  }
  historyStore.finishStreamingMessage(messageId)
}

// Init on mount
initWelcomeMessage()

const getDateLabel = (date: Date): string => {
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const messageDate = new Date(date)
  messageDate.setHours(0, 0, 0, 0)

  const diffTime = today.getTime() - messageDate.getTime()
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))

  if (diffDays === 0) return 'Today'
  if (diffDays === 1) return 'Yesterday'

  return messageDate.toLocaleDateString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
}


const groupedMessages = computed(() => {
  const groups: MessageGroup[] = []
  let currentGroup: MessageGroup | null = null

  historyStore.messages.forEach((message) => {
    const label = getDateLabel(message.timestamp)

    if (!currentGroup || currentGroup.label !== label) {
      currentGroup = { label, messages: [] }
      groups.push(currentGroup)
    }

    currentGroup.messages.push(message)
  })

  return groups
})

const scrollToBottom = () => {
  if (autoScroll.value && chatContainer.value) {
    nextTick(() => {
      if (chatContainer.value) {
        chatContainer.value.scrollTop = chatContainer.value.scrollHeight
      }
    })
  }
}

const handleScroll = () => {
  if (!chatContainer.value) return

  const { scrollTop, scrollHeight, clientHeight } = chatContainer.value
  const isAtBottom = Math.abs(scrollHeight - clientHeight - scrollTop) < 50

  autoScroll.value = isAtBottom
}

watch(() => historyStore.messages, () => {
  scrollToBottom()
}, { deep: true })

const handleSendMessage = async (content: string) => {
  autoScroll.value = true

  // Add user message
  historyStore.addMessage('user', [{ type: 'text', content }])

  // Commands have no streaming (e.g. /pic, /search)
  const parts = await executeCommand(content)
  
  // If it's a command with special parts (not just text), don't stream
  const hasNonTextParts = parts.some(p => p.type !== 'text')
  
  if (hasNonTextParts) {
    historyStore.addMessage('assistant', parts)
  } else {
    // Stream the response
    await streamAIResponse(content)
  }
}

const streamAIResponse = async (userMessage: string) => {
  streamingAbortController = new AbortController()
  
  // Get current selected model from store
  const provider = modelsStore.selectedProvider
  const model = modelsStore.selectedModel
  
  // Find model label
  const modelOption = mockModelOptions.find(
    opt => opt.provider.toLowerCase() === provider.toLowerCase() && opt.model === model
  )
  const modelLabel = modelOption?.label || model
  
  // Create empty streaming message with provider info
  const messageId = historyStore.addStreamingMessage('assistant', provider, modelLabel)
  
  try {
    // Generate Mock-Response
    const { generateMockResponse, streamText } = await import('../commands/execute')
    const fullResponse = generateMockResponse(userMessage)
    
    // Stream the response
    for await (const chunk of streamText(fullResponse)) {
      if (streamingAbortController.signal.aborted) {
        break
      }
      historyStore.updateStreamingMessage(messageId, chunk)
    }
    
    // Mark as finished
    historyStore.finishStreamingMessage(messageId)
  } catch (error) {
    historyStore.finishStreamingMessage(messageId)
  } finally {
    streamingAbortController = null
  }
}

const handleStopStreaming = () => {
  if (streamingAbortController) {
    streamingAbortController.abort()
  }
}

const handleRegenerate = async (message: Message, modelOption: ModelOption) => {
  console.log('Regenerating with model:', modelOption)
  
  streamingAbortController = new AbortController()
  
  // Mark the current message as superseded
  historyStore.markSuperseded(message.id)
  
  // Find the original user message that triggered this assistant response
  const messageIndex = historyStore.messages.findIndex(m => m.id === message.id)
  if (messageIndex > 0) {
    const previousMessage = historyStore.messages[messageIndex - 1]
    if (previousMessage.role === 'user') {
      // Extract text content from user message
      const content = previousMessage.parts
        .filter(part => part.type === 'text')
        .map(part => part.content || '')
        .join('\n')
      
      // Check if it's a command
      const parts = await executeCommand(content)
      const hasNonTextParts = parts.some(p => p.type !== 'text')
      
      if (hasNonTextParts) {
        historyStore.addMessage('assistant', parts)
        streamingAbortController = null
      } else {
        try {
          // Stream the response again with selected model
          const provider = modelOption.provider
          const modelLabel = modelOption.label
          
          // Create empty streaming message with provider info
          const messageId = historyStore.addStreamingMessage('assistant', provider, modelLabel)
          
          // Generate mock response
          const { generateMockResponse, streamText } = await import('../commands/execute')
          const fullResponse = generateMockResponse(content)
          
          // Stream the response
          for await (const chunk of streamText(fullResponse)) {
            if (streamingAbortController.signal.aborted) {
              break
            }
            historyStore.updateStreamingMessage(messageId, chunk)
          }
          
          // Mark as finished
          historyStore.finishStreamingMessage(messageId)
        } catch (error) {
          console.error('Regenerate error:', error)
        } finally {
          streamingAbortController = null
        }
      }
    }
  }
}
</script>
