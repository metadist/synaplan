<template>
  <MainLayout>
    <div class="h-full overflow-y-auto scroll-thin">
      <div class="max-w-4xl mx-auto p-4 md:p-8">
        <div class="mb-8">
          <h1 class="text-3xl font-bold txt-primary mb-2">{{ $t('profile.title') }}</h1>
          <p class="txt-secondary">{{ $t('profile.subtitle') }}</p>
        </div>

        <form @submit.prevent="handleSave" class="space-y-6">
          <section class="surface-card rounded-lg p-6">
            <h2 class="text-xl font-semibold txt-primary mb-6 flex items-center gap-2">
              <Icon icon="mdi:account" class="w-5 h-5" />
              {{ $t('profile.personalInfo.title') }}
            </h2>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.personalInfo.firstName') }}
                </label>
                <input
                  v-model="formData.firstName"
                  type="text"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.personalInfo.firstNamePlaceholder')"
                />
              </div>

              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.personalInfo.lastName') }}
                </label>
                <input
                  v-model="formData.lastName"
                  type="text"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.personalInfo.lastNamePlaceholder')"
                />
              </div>

              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.personalInfo.email') }}
                </label>
                <input
                  v-model="formData.email"
                  type="email"
                  disabled
                  class="w-full px-4 py-2.5 rounded-lg bg-chat/50 border border-light-border/30 dark:border-dark-border/20 txt-secondary cursor-not-allowed"
                  :title="$t('profile.personalInfo.emailHint')"
                />
              </div>

              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.personalInfo.phone') }}
                </label>
                <input
                  v-model="formData.phone"
                  type="tel"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.personalInfo.phonePlaceholder')"
                />
              </div>
            </div>
          </section>

          <section class="surface-card rounded-lg p-6">
            <h2 class="text-xl font-semibold txt-primary mb-2 flex items-center gap-2">
              <Icon icon="mdi:office-building" class="w-5 h-5" />
              {{ $t('profile.companyInfo.title') }}
            </h2>
            <p class="txt-secondary text-sm mb-6">{{ $t('profile.companyInfo.subtitle') }}</p>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.companyInfo.companyName') }}
                </label>
                <input
                  v-model="formData.companyName"
                  type="text"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.companyInfo.companyNamePlaceholder')"
                />
              </div>

              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.companyInfo.vatId') }}
                </label>
                <input
                  v-model="formData.vatId"
                  type="text"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.companyInfo.vatIdPlaceholder')"
                />
              </div>
            </div>
          </section>

          <section class="surface-card rounded-lg p-6">
            <h2 class="text-xl font-semibold txt-primary mb-6 flex items-center gap-2">
              <Icon icon="mdi:map-marker" class="w-5 h-5" />
              {{ $t('profile.billingAddress.title') }}
            </h2>
            
            <div class="grid grid-cols-1 gap-6">
              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.billingAddress.street') }}
                </label>
                <input
                  v-model="formData.street"
                  type="text"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.billingAddress.streetPlaceholder')"
                />
              </div>

              <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label class="block txt-primary font-medium mb-2">
                    {{ $t('profile.billingAddress.zipCode') }}
                  </label>
                  <input
                    v-model="formData.zipCode"
                    type="text"
                    class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                    :placeholder="$t('profile.billingAddress.zipCodePlaceholder')"
                  />
                </div>

                <div class="md:col-span-2">
                  <label class="block txt-primary font-medium mb-2">
                    {{ $t('profile.billingAddress.city') }}
                  </label>
                  <input
                    v-model="formData.city"
                    type="text"
                    class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                    :placeholder="$t('profile.billingAddress.cityPlaceholder')"
                  />
                </div>
              </div>

              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.billingAddress.country') }}
                </label>
                <select
                  v-model="formData.country"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                >
                  <option v-for="country in countries" :key="country.code" :value="country.code">
                    {{ country.name }}
                  </option>
                </select>
              </div>
            </div>
          </section>

          <section class="surface-card rounded-lg p-6">
            <h2 class="text-xl font-semibold txt-primary mb-6 flex items-center gap-2">
              <Icon icon="mdi:cog" class="w-5 h-5" />
              {{ $t('profile.accountSettings.title') }}
            </h2>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.accountSettings.language') }}
                </label>
                <select
                  v-model="formData.language"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                >
                  <option v-for="lang in languages" :key="lang.code" :value="lang.code">
                    {{ lang.name }}
                  </option>
                </select>
              </div>

              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.accountSettings.timezone') }}
                </label>
                <select
                  v-model="formData.timezone"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                >
                  <option v-for="tz in timezones" :key="tz.value" :value="tz.value">
                    {{ tz.label }}
                  </option>
                </select>
              </div>

              <div class="md:col-span-2">
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.accountSettings.invoiceEmail') }}
                </label>
                <input
                  v-model="formData.invoiceEmail"
                  type="email"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.accountSettings.invoiceEmailPlaceholder')"
                />
              </div>
            </div>
          </section>

          <section class="surface-card rounded-lg p-6">
            <h2 class="text-xl font-semibold txt-primary mb-2 flex items-center gap-2">
              <Icon icon="mdi:lock" class="w-5 h-5" />
              {{ $t('profile.changePassword.title') }}
            </h2>
            <p class="txt-secondary text-sm mb-6">{{ $t('profile.changePassword.subtitle') }}</p>
            
            <div class="grid grid-cols-1 gap-6 max-w-2xl">
              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.changePassword.currentPassword') }}
                </label>
                <input
                  v-model="passwordData.current"
                  type="password"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.changePassword.currentPasswordPlaceholder')"
                />
              </div>

              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.changePassword.newPassword') }}
                </label>
                <input
                  v-model="passwordData.new"
                  type="password"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.changePassword.newPasswordPlaceholder')"
                />
                <p class="txt-secondary text-sm mt-1">{{ $t('profile.changePassword.newPasswordHint') }}</p>
              </div>

              <div>
                <label class="block txt-primary font-medium mb-2">
                  {{ $t('profile.changePassword.confirmPassword') }}
                </label>
                <input
                  v-model="passwordData.confirm"
                  type="password"
                  class="w-full px-4 py-2.5 rounded-lg bg-chat border border-light-border/30 dark:border-dark-border/20 txt-primary focus:ring-2 focus:ring-[var(--brand)] focus:outline-none"
                  :placeholder="$t('profile.changePassword.confirmPasswordPlaceholder')"
                />
                <p class="txt-secondary text-sm mt-1">{{ $t('profile.changePassword.confirmPasswordHint') }}</p>
              </div>
            </div>
          </section>

          <div class="surface-card rounded-lg p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
            <p class="txt-secondary text-sm flex items-start gap-2">
              <Icon icon="mdi:information" class="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>{{ $t('profile.privacyNotice') }}</span>
            </p>
          </div>

          <div class="h-20"></div>
        </form>
      </div>
    </div>

    <UnsavedChangesBar
      :show="hasUnsavedChanges"
      @save="handleSave"
      @discard="handleDiscard"
    />
  </MainLayout>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import { Icon } from '@iconify/vue'
import MainLayout from '@/components/MainLayout.vue'
import UnsavedChangesBar from '@/components/UnsavedChangesBar.vue'
import { mockProfile, countries, languages, timezones, type UserProfile } from '@/mocks/profile'
import { useNotification } from '@/composables/useNotification'
import { useUnsavedChanges } from '@/composables/useUnsavedChanges'

const { error } = useNotification()

const formData = ref<UserProfile>({ ...mockProfile })
const originalData = ref<UserProfile>({ ...mockProfile })
const passwordData = ref({
  current: '',
  new: '',
  confirm: '',
})

const { hasUnsavedChanges, saveChanges, discardChanges, setupNavigationGuard } = useUnsavedChanges(
  formData,
  originalData
)

let cleanupGuard: (() => void) | undefined

onMounted(() => {
  cleanupGuard = setupNavigationGuard()
})

onUnmounted(() => {
  cleanupGuard?.()
})

const handleSave = saveChanges(() => {
  if (passwordData.value.new && passwordData.value.new !== passwordData.value.confirm) {
    error('Passwords do not match')
    throw new Error('Validation failed')
  }

  if (passwordData.value.new && passwordData.value.new.length < 8) {
    error('Password must be at least 8 characters')
    throw new Error('Validation failed')
  }

  // API call would go here
  console.log('Saving profile:', formData.value)
  passwordData.value = { current: '', new: '', confirm: '' }
})

const handleDiscard = () => {
  discardChanges()
  passwordData.value = { current: '', new: '', confirm: '' }
}
</script>

