import { ref, computed } from 'vue'

// Mock authentication state
const isAuthenticated = ref(false)
const user = ref<{
  id: string
  name: string
  email: string
} | null>(null)

export function useAuth() {
  // In a real app, check token/session from localStorage/API
  const checkAuth = () => {
    const token = localStorage.getItem('auth_token')
    isAuthenticated.value = !!token
    
    // Mock user data
    if (token) {
      user.value = {
        id: '152',
        name: 'Demo User',
        email: 'demo@example.com'
      }
    } else {
      user.value = null
    }
    
    return isAuthenticated.value
  }

  const login = async (email: string, password: string) => {
    // Mock login - replace with actual API call
    return new Promise<boolean>((resolve) => {
      setTimeout(() => {
        if (email && password) {
          localStorage.setItem('auth_token', 'mock-token-' + Date.now())
          isAuthenticated.value = true
          user.value = {
            id: '152',
            name: 'Demo User',
            email
          }
          resolve(true)
        } else {
          resolve(false)
        }
      }, 500)
    })
  }

  const logout = () => {
    localStorage.removeItem('auth_token')
    isAuthenticated.value = false
    user.value = null
  }

  const requireAuth = computed(() => isAuthenticated.value)

  // Initialize auth state
  checkAuth()

  return {
    isAuthenticated: computed(() => isAuthenticated.value),
    user: computed(() => user.value),
    requireAuth,
    login,
    logout,
    checkAuth
  }
}

